package mods.nandonalt.coralmod;

public class CommonProxy {

	public void clientSetup() {}

}