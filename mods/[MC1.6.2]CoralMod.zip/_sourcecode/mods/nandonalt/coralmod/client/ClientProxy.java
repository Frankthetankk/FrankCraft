package mods.nandonalt.coralmod.client;

import cpw.mods.fml.client.registry.KeyBindingRegistry;
import mods.nandonalt.coralmod.CommonProxy;
import net.minecraft.client.Minecraft;

public class ClientProxy extends CommonProxy {

	@Override
	public void clientSetup() {
		KeyBindingRegistry.registerKeyBinding(new CoralKeyHandler());
		startCoralThread();
	}

	private void startCoralThread() {
		Thread thread = new ThreadCoralReefGUIHelper(Minecraft.getMinecraft(), "CoralMod GUI Helper");
		thread.setDaemon(true);
		thread.start();
	}

}