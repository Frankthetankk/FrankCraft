package mods.nandonalt.coralmod.client;

import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;

public class ThreadCoralReefGUIHelper extends Thread {

	/** A reference to the Minecraft object. */
	final Minecraft mc;

	private static boolean listening = true;

	public ThreadCoralReefGUIHelper(Minecraft par1Minecraft, String name) {
		super(name);
		this.mc = par1Minecraft;
	}

	public void run() {
		while (listening) {
			if(this.mc == null || !Keyboard.isCreated()) {
				listening = false;
				System.out.println("Shutting down Coral Reef GUI Helper Thread.");
				return;
			}
			try {
				if(this.mc.currentScreen instanceof GuiOptions) {
					if(Keyboard.isKeyDown(CoralKeyHandler.binding.keyCode)) {
						this.mc.displayGuiScreen(new GuiCoralReef());
					}
				}
			} catch (Throwable t) {
				t.printStackTrace();
				listening = false;
			}
			try {
				sleep(50L);
			} catch (InterruptedException ie) {
				;
			}
		}
	}
}
